


<!DOCTYPE html>
<html lang="en">

<head>



    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <link rel="canonical" href="https://somervilleinternational.in/" />
    <meta property="og:url" content="https://somervilleinternational.in/" />
    <meta name="author" content="Edunext Technologies" />
    <meta name="google-site-verification" content="JBT5oom5YFc9apZrP1pTmWLKOWLdIqS2fRW-VLSFfYM" />


    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-2G0NQL8V8Q"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        gtag('config', 'G-2G0NQL8V8Q');
    </script>

    <title>    </title>

    <!-- Stylesheets -->
    <meta name="robots" content="index, follow">

    <meta property="og:site_name" content="Somerville International School" />
    <meta property="og:type" content="website" />

    <meta property="og:image" content="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/new-logo-2.png" />
    <meta property="og:image:width" content="2182" />
    <meta property="og:image:height" content="541" />
    <meta name="og:email" content="school@somervilleinternational.in" />
    <meta name="og:phone_number" content="+91-9650506358" />

    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">
    <link href="assets/css/color.css" rel="stylesheet">
    <link href="assets/css/fontawesome-all.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/custom-animate.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/swiper.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="shortcut icon" href="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/somervilleinternational-favicon.png" type="image/x-icon">
    <link rel="icon" href="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/somervilleinternational-favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="https://rawgit.com/LeshikJanz/libraries/master/Bootstrap/baguetteBox.min.css">

    <!-- Responsive -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-5ZK69HT');
    </script>
    <!-- End Google Tag Manager -->

</head>

<body>
    <div class="page-wrapper">

        <!-- Main Header -->
        <header class="main-header header-style-one bg-light">

            <div class="rs-toolbar bg-danger text-white">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="rs-toolbar-left">
                                <div class="welcome-message d-flex justify-content-between align-items-center w-100">
                                    <span class="rs-toolbar-start">
                                        <a href="tel:+919650506358" target="_blank"><i class="fa fa-phone mr-1"></i>
                                            +91-9650506358</a> <span class="divider mx-2">|</span>
                                        <a href="mailto:school@somervilleinternational.in" target="_blank"><i class="fa fa-envelope mr-1"></i> school@somervilleinternational.in</a>
                                    </span>
                                    <!-- <span class="rs-toolbar-start d-none d-lg-block">
                                        Affiliated To C.B.S.E <span class="divider mx-2">|</span> Code No : 2132183
                                    </span> -->
                                    <span class="rs-toolbar-end d-none d-lg-block social-icon-h">
                                        <a href="https://www.instagram.com/somervilleinternational/" target="_blank">
                                            <!-- <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/somervilleinternational-instagram.png"
                                                class="img-fluid" alt="Somerville International School, Noida" width=""> -->
                                            <i class="fa fa-instagram" aria-hidden="true"></i>
                                        </a>
                                        <a href="https://www.facebook.com/people/Somerville-International-School/61550647783215/?mibextid=hIlR13" target="_blank">
                                            <!-- <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/fb-icon.svg"
                                                class="img-fluid" alt="Somerville International School, Noida" width=""> -->
                                            <i class="fa fa-facebook" aria-hidden="true"></i>
                                        </a>
                                        <a href="https://www.youtube.com/channel/UCE0-GLJEFuQsDbtKHw__XCQ" target="_blank">
                                            <!-- <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/YouTube1.png"
                                                class="img-fluid" alt="Somerville International School, Noida" width=""> -->
                                            <i class="fa fa-youtube-play" aria-hidden="true"></i>
                                        </a>
                                        <a href="https://wa.me/+919650506358" target="_blank">
                                            <!-- <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/whatsapp-icon.png"
                                                class="img-fluid" alt="Somerville International School, Noida" width=""> -->
                                            <i class="fa fa-whatsapp" aria-hidden="true"></i>
                                        </a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Header Top -->
            <div class="header-top">
                <div class="auto-container">
                    <div class="inner-container">
                        <div class="left-column d-block">
                            <div class="left-img-column">
                                <a href="https://somervilleinternational.in/"><img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/somerville-new-logo.png" class="img-fluid" alt="Somerville International School, Noida Logo" width="450"></a>
                            </div>
                        </div>
                        <div class="main-menu main-menu-1 right-column d-flex align-items-center">
                            <ul class="btns-link">
                                <!-- <li><a href="https://sisnoida.edunexttechnologies.com/" target="_blank"
                                        class="erp-login erp-login-button btn btn-outline-danger">Edunext
                                        ERP<sup>TM</sup> Login</a></li> -->
                                <!-- <li><a href="https://forms.edunexttechnologies.com/forms/sisnoida/index.html"
                                        target="_blank" class="erp-login btn btn-primary">Contact Us</a>
                                            </li> -->
                                <li><a href="https://sisnoida.edunexttechnologies.com/" class="new-btn" target="_blank"><span class="i-icon"><i class="fa fa-sign-in"></i></span><span class="n-text">Edunext ERP<sup>TM</sup> Login</span></a></li>
                                <li><a href="fee_payment.php" class="new-btn" target="_blank"><span class="i-icon"><i class="fa fa-inr"></i></span><span class="n-text">Fee
                                            Payment</span></a></li>
                                <li><a href="contact-us.php" class="new-btn" target="_blank"><span class="i-icon"><i class="fa fa-address-book-o"></i></span><span class="n-text">Contact
                                            Us</span></a></li>
                                <!-- <li><a href="https://sisnoida.edunexttechnologies.com/DirectStudentOnlineFee"
                                        target="_blank" class="erp-login btn btn-primary">Pay Fee Online</a></li> -->
                                <!-- <li><a href="https://resources.edunexttechnologies.com/ppt/Somervill-School.pdf"
                                        target="_blank" class="erp-login btn btn-primary">Mobile App Manual</a></li> -->
                                <!-- <li><a href="https://sisnoida.edunexttechnologies.com/mvc/std/DynamicEnquiryForm?id=gm44E2x75eawnpF5K7VGUQ&istrue=true"
                                        target="_blank" class="erp-login btn btn-primary">Enquiry Form</a></li> -->
                                <!-- <li><a href="https://forms.edunexttechnologies.com/forms/somerville-nursery/registration/"
                                        target="_blank" class="erp-login btn btn-primary">Online Admissions</a>
                                </li> -->

                                <!-- <li class="dropdown  erp-login  btn btn-primary">Online Admissions
                                    <ul class="">
                                        <li class=""><a href="admission_nursery">Admission to Nursery</a></li>
                                        <li class=""><a href="admission_kg">Admission to K.G</a></li>
                                        <li class=""><a href="admission_i_v">Admission to Classes I-V</a></li>
                                        <li class=""><a href="admission_vi_ix_xi">Admission to Classes VI-IX &
                                                XI</a></li>
                                    </ul>

                                </li> -->


                            </ul>
                        </div>
                    </div>
                </div>
            </div>



            <!-- Header Upper -->
            <div class="header-upper">
                <div class="auto-container">
                    <div class="row justify-content-end">
                        <div class="col-md-8">
                            <div class="right-column">
                                <!--Nav Box-->
                                <div class="navbar navbar-expand-lg navbar-light bg-navber">
                                    <div class="nav-outer">
                                        <!--Mobile Navigation Toggler-->
                                        <div class="mobile-nav-toggler"><img src="https://resources.edunexttechnologies.com/assets/images/menu-icon-bar.png" alt="Somerville International School, Noida"></div>

                                        <!-- Main Menu -->
                                        <nav class="main-menu navbar-expand-md navbar-light">
                                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                                <ul class='navigation'><li class='' ><a   href='https://somervilleinternational.in/'> Home</a></li><li class='dropdown'  ><a  href='#'>About Us</a><ul class=''><li class='dropdown' ><a  href='#'>History</a><ul  class='sub-menu'><li ><a  href='about-the-school'>The School</a></li><li ><a  href='the-lott-carey-mission'>The Lott Carey Baptist Mission</a></li></ul><li class="" ><a  href='vision-mission-moto'>Vision, Mission & Motto</a><li class="" ><a  href='board-of-management.php'>Management & Administration</a></li></ul></li><li class='dropdown'  ><a  href='#'>Prospectus</a><ul class=''><li class="" ><a  href='school-song'>School Song</a><li class="" ><a  href='school-status'>School Status</a><li class="" ><a  href='curriculum'>Curriculum</a><li class="" ><a  href='infrastructure-new'>Infrastructure</a><li class="" ><a  href='school-timings'>School Timings</a><li class="" ><a  href='uniform'>Uniform</a><li class="" ><a  href='list-of-holidays'>List of Holidays</a><li class="" ><a  href='https://resources.edunexttechnologies.com/web-data/somervilleinternational/pdf/TEACHER_WORKSHOP.pdf'>Staff Development</a></li></ul></li><li class='dropdown'  ><a  href='#'>School Levels</a><ul class=''><li class="" ><a  href='preparatory-school'>Preparatory School</a><li class="" ><a  href='primary-school'>Primary School</a><li class="" ><a  href='secondary-school'>Secondary School</a><li class="" ><a  href='senior-secondary-school'>Senior-Secondary School</a></li></ul></li><li class='dropdown'  ><a  href='#'>Student Life</a><ul class=''><li class="" ><a  href='clubs.php'>Clubs</a><li class="" ><a  href='sports'>Sports</a><li class="" ><a  href='olympiads'>Olympiads</a><li class="" ><a  href='intra-school-activities'>Intra-school Activities</a><li class="" ><a  href='inter-school-activities'>Inter-school Activities</a><li class="" ><a  href='counselling-and-guidance-department'>Counselling And Guidance Department</a><li class="" ><a  href='community-service'>Community Service</a><li class="" ><a  href='house-system-and-student-council'>House System and Student Council</a></li></ul></li><li class='dropdown'  ><a  href='#'>Admissions</a><ul class=''><li class="" ><a  href='admission-process'>Admission Process</a><li class="" ><a  href='forms.php'>Admission Registration Form</a><li class="" ><a  href='fee-structure'>Fee Structure</a><li class="" ><a  href='faq'>FAQ</a></li></ul></li><li class='dropdown'  ><a  href='#'>Gallery</a><ul class=''><li class="" ><a  href='gallery.php'>Photo Gallery</a><li class="" ><a  href='video-gallery.php'>Video Gallery</a><li class="" ><a  href='wall-magazine'>School Magazine</a><li class="" ><a  href='class-photographs.php'>Class Photographs</a><li class="" ><a  href='all-testimonials.php'>Testimonials</a></li></ul></li><li class='' ><a   href='career.php'> Careers</a></li><li class='dropdown'  ><a  href='#'>Transfer Certificate</a><ul class=''><li class="" ><a  href='pdf/Application-form-for-TC-1.pdf'>Apply</a><li class="" ><a  href='transfer-certificate'>Access</a></li></ul></li></ul>                                            </div>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Header Upper-->

            <!-- Sticky Header  -->
            <div class="sticky-header">
                <div class="header-upper">
                    <div class="auto-container">
                        <div class="inner-container">
                            <div class="right-column">
                                <!--Nav Box-->
                                <div class="nav-outer">
                                    <!--Mobile Navigation Toggler-->
                                    <div class="mobile-nav-toggler"><img src="https://resources.edunexttechnologies.com/assets/images/menu-icon-bar.png" alt="Somerville International School, Noida"></div>

                                    <!-- Main Menu -->
                                    <nav class="main-menu navbar-expand-md navbar-light">
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- End Sticky Menu -->

            <!-- Mobile Menu  -->
            <div class="mobile-menu">
                <div class="menu-backdrop"></div>
                <div class="close-btn"><span class="icon fa fa-times"></span></div>

                <nav class="menu-box">
                    <div class="nav-logo"><a href="https://somervilleinternational.in/">
                            <!-- <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/footer-new-logo-1.png"
                                width="230" alt="Somerville International School, Noida Logo" title=""> -->
                            <div style=" margin-bottom: 20px;" class="d-flex">
                                <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/SIS-logo-white.png" alt="Somerville International School, Noida Logo" style="width: 21%;">
                                <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/footer-logo-new-2_n.png" alt="Somerville International School, Noida Logo" style="width: 84%;margin-left: 4px;">
                            </div>
                        </a></div>
                    <div class="menu-outer">
                        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                    </div>
                    <!--Social Links-->
                    <div class="social-links">
                        <ul class="clearfix social-icon-h-m">
                            <li><a href="https://instagram.com/somervilleinternational" target="_blank" class=""><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://www.facebook.com/people/Somerville-International-School/61550647783215/?mibextid=hIlR13" target="_blank" class=""><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://www.youtube.com/channel/UCE0-GLJEFuQsDbtKHw__XCQ" target="_blank" class=""><i class="fa fa-youtube"></i></a></li>
                            <li><a href="https://wa.me/+919650506358" target="_blank" class=""><i class="fa fa-whatsapp"></i></a></li>
                        </ul>
                    </div>
                </nav>
            </div><!-- End Mobile Menu -->

            <div class="nav-overlay">
                <div class="cursor"></div>
                <div class="cursor-follower"></div>
            </div>
        </header>
        <!-- End Main Header -->

        <style>
            .navbar-nav li:hover>ul.dropdown-menu {
                display: block;
            }

            .dropdown-submenu {
                position: relative;
            }

            .dropdown-submenu>.dropdown-menu {
                top: 0;
                left: 100%;
                margin-top: -6px;
            }

            /* rotate caret on hover */
            .dropdown-menu>li>a:hover:after {
                text-decoration: underline;
                transform: rotate(-90deg);
            }
        </style><style>
    .about-details {
        padding: 0;
    }

    .acc-view img {
        margin-bottom: 10px;
        position: relative;
        border: 1px solid #247CFF26;
        border-radius: 7px 0px;
    }

    .year-sel .form-group {
        width: 150px;
        max-width: 150px;
    }
</style>
<style>
    .loader {
        background-color: transparent;
        display: flex;
        justify-content: center;
        height: 93vh;
        align-items: center;
        position: fixed;
        top: 0;
        width: 100%;
    }

    .loader svg path,
    svg rect {
        fill: #740F13;
    }
</style>
<div class="loader loader--style6" style="display: none;z-index:9999;" title="5">
    <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
        x="0px" y="0px" width="80px" height="86px" viewBox="0 0 24 30" style="enable-background:new 0 0 50 50;"
        xml:space="preserve">
        <rect x="0" y="13" width="4" height="5" fill="#333">
            <animate attributeName="height" attributeType="XML" values="5;21;5" begin="0s" dur="0.6s"
                repeatCount="indefinite" />
            <animate attributeName="y" attributeType="XML" values="13; 5; 13" begin="0s" dur="0.6s"
                repeatCount="indefinite" />
        </rect>
        <rect x="10" y="13" width="4" height="5" fill="#333">
            <animate attributeName="height" attributeType="XML" values="5;21;5" begin="0.15s" dur="0.6s"
                repeatCount="indefinite" />
            <animate attributeName="y" attributeType="XML" values="13; 5; 13" begin="0.15s" dur="0.6s"
                repeatCount="indefinite" />
        </rect>
        <rect x="20" y="13" width="4" height="5" fill="#333">
            <animate attributeName="height" attributeType="XML" values="5;21;5" begin="0.3s" dur="0.6s"
                repeatCount="indefinite" />
            <animate attributeName="y" attributeType="XML" values="13; 5; 13" begin="0.3s" dur="0.6s"
                repeatCount="indefinite" />
        </rect>
    </svg>
</div>
<!-- Page Title -->
<section class="page-title"
    style="background: url(https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/internal-top.svg) no-repeat; background-size: cover; background-position: center;">
    <div class="container">
        <div class="content-box">
            <div class="content-wrapper">
                <div class="title">
                    <h1>Achievements</h1>
                </div>
                <!-- <ul class="bread-crumb">
                    <li><a href="index.php">Home</a></li>
                    <li>Achievement</li>
                </ul> -->
            </div>
        </div>
    </div>
</section>

<!-- Blog Section -->
<section class="blog-section about-section about-inner-section p-0">
    <div class="inner-page-bg">
        <!-- <div class="innerpage-top">
            <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/assets-1.gif"
                alt="somervilleinternational">
        </div> -->
        <div class="container py-4">

            <div class="row mt-3 mb-lg-4 mb-3 mx-lg-4 px-lg-3">
                <div class="year-sel w-100 d-flex justify-content-end">
                    <div class="form-group mb-0">
                        <select class="form-control" id="ydata">
                            <option value="-1">Select Year </option>
                            <option selected value="2024">2024</option>
                            <option value="2023">2023</option>
                            <option value="2021">2021</option>
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>

                        </select>
                    </div>
                </div>

            </div>
            <div class="row mx-lg-4" id="fdata">
                <!--Accordion Block-->

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=81">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733893985171_43.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=81"><b>KALAAKRITI MEDALS</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 11-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=88">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733896063628_50.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=88"><b>ECO CODERS</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 11-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=84">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733895253566_46.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=84"><b>NUKKAD NATAK</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 11-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=82">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733893317365_44.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=82"><b>ABHIVYAKTI - KAHANI VACHAN</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 11-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=83">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733893434057_45.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=83"><b>ABHIVYAKTI - PATR CHITRANKAN, DOHA VACHAN</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 11-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=85">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733895418273_47.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=85"><b>JUST A MINUTE</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 11-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=86">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733895569729_48.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=86"><b>AASHU BHASHAN</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 11-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=87">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733895921954_49.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=87"><b>SCINTILLATION</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 11-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=79">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733729398502_41.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=79"><b>KNOWLEDGE CONCLAVE - SLAM POETRY, BOOK COVER DESIGNING</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 09-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=80">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733732077474_42.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=80"><b>FUN WITH SHAPES</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 09-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=75">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733547764961_37.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=75"><b>LIBERATE D'EXPRESSION 4.0</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 07-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=76">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733547878736_38.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=76"><b>LIBERATE D'EXPRESSION 4.0</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 07-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=77">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733549217341_39.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=77"><b>INCOGNITO</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 07-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=78">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733551952403_40.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=78"><b>SCIENCE SYMPOSIUM</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 07-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=74">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733457650399_36.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=74"><b>THE IMMORTALVERSE - CALLIGRAPHY</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 06-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=73">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733282799845_35.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=73"><b>LITTLE STAR OLYMPIAD MEDAL</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 04-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=72">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733210932217_34.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=72"><b>LOVE IN ACTION ASIA BASKETBALL TOURNAMENT (BOYS)</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 03-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=69">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733205080606_31.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=69"><b>LITTLE STAR OLYMPIAD MEDAL</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 03-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=70">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733206503856_32.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=70"><b>LITTLE STAR OLYMPIAD MEDAL</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 03-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=71">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733210182109_33.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=71"><b>LITTLE STAR OLYMPIAD MEDAL</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 03-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=63">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733118324982_25.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=63"><b>SOF OLYMPIAD MEDALS</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 02-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=64">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733123488752_26.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=64"><b>SOF OLYMPIAD MEDALS</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 02-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=65">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733124646454_27.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=65"><b>SOF OLYMPIAD MEDALS</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 02-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=66">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733125590483_28.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=66"><b>SOF OLYMPIAD MEDALS</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 02-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=67">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733126082623_29.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=67"><b>SOF OLYMPIAD MEDALS</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 02-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=68">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1733126924894_30.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=68"><b>SOF OLYMPIAD MEDALS</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 02-Dec-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=57">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732943041376_19.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=57"><b>NATIONAL TAEKWONDO CHAMPIONSHIP</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 30-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=58">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732948544426_20.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=58"><b>SOF OLYMPIAD MEDAL WINNERS</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 30-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=59">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732948724578_21.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=59"><b>SOF OLYMPIAD MEDAL WINNERS</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 30-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=60">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732948888250_22.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=60"><b>SOF OLYMPIAD MEDAL WINNERS</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 30-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=61">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732949009237_23.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=61"><b>SOF OLYMPIAD MEDAL WINNERS</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 30-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=62">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732949132803_24.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=62"><b>SOF OLYMPIAD MEDAL WINNERS</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 30-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=50">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732858617077_12.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=50"><b>SAPTAK SA RE GA MA</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 29-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=51">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732863668554_13.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=51"><b>FANTASY COMES ALIVE</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 29-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=52">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732863680127_14.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=52"><b>RASHMI GUNJAN & KAHANI KA SAFAR</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 29-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=53">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732863693053_15.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=53"><b>TAPESTRY OF FOLKTALES</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 29-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=54">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732867163356_16.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=54"><b>MATHEMATICS RUMBLE</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 29-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=55">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732867325137_17.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=55"><b>EARTH'EDEN</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 29-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=56">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732867405891_18.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=56"><b>EXPRESSIVE ECHOES</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 29-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=49">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732857885445_11.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=49"><b>LOVE IN ACTION ASIA BASKETBALL TOURNAMENT (GIRLS)</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 29-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=43">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732772352386_5.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=43"><b>CLAY CO COMPETITION</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 28-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=44">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732772541771_6.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=44"><b>TRASH TO TREASURE</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 28-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=45">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732772752117_7.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=45"><b>KNOWLEDGE CONCLAVE - EXTEMPORE</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 28-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=46">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732775318924_81.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=46"><b>FRACTIONAL FANTASIA</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 28-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=47">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732780468295_9.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=47"><b>CLIMATE CROSSROADS</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 28-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=48">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732780267230_10.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=48"><b>FUSION DANCE (WESTERN)</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 28-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=39">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732694674979_1.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=39"><b>YOGA INTER SCHOOL COMPETITION</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 27-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=40">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732696060976_2.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=40"><b>RHYME RECITATION COMPETITION</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 27-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=41">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732696315297_3.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=41"><b>SDG COLLOQUIUM - ENROUTE</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 27-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
                        <div class="col-md-4">
                            <div class="acc-card mb-4">
                                <div class="acc-view">
                                    <a href="awards-detail.php?id=42">
                                                                                    <img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1732696602061_4.jpeg"
                                                class="img-fluid w-100" alt="Somerville International School, Noida">
                                                                            </a>
                                </div>
                                <div class="acc-content px-2">
                                    <h6 class="mb-2"><a
                                            href="awards-detail.php?id=42"><b>B.O.T. LOGO FUSION</b></a>
                                    </h6>
                                    <p class="text-danger"><i class="fa fa-calendar mr-2"></i> 27-Nov-2024</p>
                                </div>
                            </div>
                        </div>

                
            </div>
        </div>
        <!-- <div class="inner-page-buttom">
            <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/assets-1.gif"
                alt="somervilleinternational">
        </div> -->
    </div>
</section>




    <footer class="main-footer pt-4 pt-md-0 mt-0" style="background: url('https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/somervilleinternational-footer-bg.png') no-repeat; background-size: cover; background-position: center;">
        <div class="container-fluid">
            <!--Widgets Section-->
            <div class="widgets-section">
                <div class="row clearfix justify-content-between">

                    <!--Column-->
                    <div class="column col-lg-4 col-md-6">
                        <div class="widget contact-widget about-widget py-md-4 pt-lg-5">
                            <div class="widget-content">
                                <div style=" margin-bottom: 20px;" class="d-flex">
                                    <a href="https://somervilleinternational.in/">
                                        <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/SIS-logo-white.png" alt="Somerville International School, Noida Logo" style="width: 20%;">
                                        <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/footer-logo-new-2_n.png" alt="Somerville International School, Noida Logo" style="width: 77%; margin-left: 4px;">
                                    </a>
                                </div>
                                <p class="text-white text-justify d-none d-md-block">The mission of the school is to
                                    provide myriad opportunities to
                                    each child. The school believes that each child is unique and special and is blessed
                                    with immense potential. The endeavour is to guide each child as he/she charters a
                                    route to happiness and excellence.</p>
                                <ul class="social-links wow fadeInLeft social-icon">
                                    <li><a href="https://www.instagram.com/somervilleinternational/" target="_blank">
                                           
                                            <i class="fa fa-instagram" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.facebook.com/people/Somerville-International-School/61550647783215/?mibextid=hIlR13" target="_blank">
                                            <i class="fa fa-facebook" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.youtube.com/channel/UCE0-GLJEFuQsDbtKHw__XCQ" target="_blank">                      
                                            <i class="fa fa-youtube-play" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://wa.me/+919650506358" target="_blank">
            
                                            <i class="fa fa-whatsapp" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!--Column-->
                    <div class="column col-lg-4 col-md-6">
                        <div class="widget contact-widget about-widget py-md-4 pt-lg-5 mb-4">
                            <h3 class="widget-title">Quick Links</h3>
                            <div class="widget-content">
                                <div class="row">
                                    <div class="col-md-6">
                                        <ul class="contact-info">
                                            <li class="wow fadeInUp" >
                                                <a href="about-the-school" target="_blank">The School</a>
                                            </li>
                                            <li class="wow fadeInUp">
                                                <a href="admission-process" target="_blank">Admission Process</a>
                                            </li>

                                            <li class="wow fadeInUp">
                                                <a href="clubs.php" target="_blank">Clubs</a>
                                            </li>
                                            <li class=" wow fadeInUp">
                                                <a href="gallery.php" target="_blank">Photo Gallery</a>
                                            </li>
                                            <li class=" wow fadeInUp">
                                                <a href="career.php" target="_blank">Careers</a>
                                            </li>
                                            <li class="wow fadeInUp">
                                                <a href="contact-us.php" target="_blank">Contact Us</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="app-store mt-3 mt-md-0">
                                            <a href="https://play.google.com/store/search?q=edunext+parent&c=apps&pli=1" class="" target="_blank"><img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/gp.png" class="mt-md-3 mb-md-3 mb-sm-3" alt="Somerville International School, Noida"></a>
                                            <a href="https://apps.apple.com/in/app/edunext-parent/id1516241231" class="" target="_blank"><img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/as.png" class="mt-md-3 mb-md-3 mb-sm-3" alt="Somerville International School, Noida"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                    <div class="column col-lg-4 col-md-6 p-md-0 d-none d-md-block">                   
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7012.042259354631!2d77.374881!3d28.509012000000002!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce629043d5d05%3A0x7635abf24b6a4c2a!2sSomerville%20International%20School!5e0!3m2!1sen!2sus!4v1703069423213!5m2!1sen!2sus" width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>

                </div>
            </div>
        </div>
        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="container auto-container">
                <div class="wrapper-box">
                    <div class="copyright">
		    <div class="text">Ⓒ Copyright 2025 <br class="d-block d-md-none"><span class="text-warning">|</span> <span class="Lincoln ">Somer<span class="Alpine v-size3">v</span>ille International
                                School</span> <br class="d-block d-md-none"> <span class="text-warning">|</span>
                            Designed & Maintained by <a href="https://edunexttechnologies.com/" target="_blank" class="text-light">Edunext
                                Technologies</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    </div>
    <!--End pagewrapper-->

    <!--Scroll to top-->
    <div class="scroll-to-top scroll-to-target" data-target="html">
        <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/46.svg">
    </div>

    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/fjs.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js">
    </script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/swiper.min.js"></script>
    <script src="assets/js/modernizr-custom.js"></script>
    <script src="assets/js/jquery.slicebox.js"></script>
    <script src="assets/js/script.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#newmodal').modal('show');
        });
    </script>

    <script>
        $(".link").on('click', function() {
            $(".link").removeClass('active');
            $(this).addClass('active');
            var $submenu_first = $(this).next(".submenu");
            var $arrow_first = $(this).find('.arrow-up');

            if ($submenu_first.is(":visible")) {
                $submenu_first.slideUp();
                $(this).removeClass('active');
                $arrow_first.animate({
                    rotation: 0
                }, {
                    step: function(now, fx) {
                        $(this).css('transform', 'rotate(' + now + 'deg)');
                    },
                    duration: 'slow'
                });
            } else {
                $(".submenu").slideUp();
                $submenu_first.slideDown();
                $arrow_first.animate({
                    rotation: 90
                }, {
                    step: function(now, fx) {
                        $(this).css('transform', 'rotate(' + now + 'deg)');
                    },
                    duration: 'slow'
                });
            }
        });
    </script>

    <script type="text/javascript">
        $(function() {

            var Page = (function() {

                var $navArrows = $('#nav-arrows').hide(),
                    $shadow = $('#shadow').hide(),
                    slicebox = $('#sb-slider').slicebox({
                        onReady: function() {

                            $navArrows.show();
                            $shadow.show();

                        },
                        orientation: 'r',
                        cuboidsRandom: true
                    }),

                    init = function() {

                        initEvents();

                    },
                    initEvents = function() {

                        // add navigation events
                        $navArrows.children(':first').on('click', function() {

                            slicebox.next();
                            return false;

                        });

                        $navArrows.children(':last').on('click', function() {

                            slicebox.previous();
                            return false;

                        });

                    };

                return {
                    init: init
                };

            })();

            Page.init();

        });
    </script>

    <script>
        baguetteBox.run('#gallery');
    </script>

    <script type="text/javascript">
        $(document).ready(function() {
            $(".team_carousel").owlCarousel({
                navigation: false,
                slideSpeed: 500,
                paginationSpeed: 800,
                rewindSpeed: 1000,
                singleItem: true,
                autoPlay: false,
                stopOnHover: true,
                nav: true,
                dots: true,
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            var sync1 = $("#sync1");
            var sync2 = $("#sync2");
            var slidesPerPage = 4; //globaly define number of elements per page
            var syncedSecondary = true;
            sync1.owlCarousel({
                items: 1,
                slideSpeed: 2000,
                nav: true,
                autoplay: false,
                dots: false,
                loop: true,
                responsiveRefreshRate: 200,
                navText: [
                    '<svg width="100%" height="100%" viewBox="0 0 11 20"><path style="fill:none;stroke-width: 2px;stroke: #fff;" d="M9.554,1.001l-8.607,8.607l8.607,8.606"/></svg>',
                    '<svg width="100%" height="100%" viewBox="0 0 11 20" version="1.1"><path style="fill:none;stroke-width: 2px;stroke: #fff;" d="M1.054,18.214l8.606,-8.606l-8.606,-8.607"/></svg>'
                ],
            }).on('changed.owl.carousel', syncPosition);

            sync2
                .on('initialized.owl.carousel', function() {
                    sync2.find(".owl-item").eq(0).addClass("current");
                })
                .owlCarousel({
                    items: slidesPerPage,
                    dots: false,
                    nav: true,
                    smartSpeed: 200,
                    slideSpeed: 500,
                    slideBy: slidesPerPage, //alternatively you can slide by 1, this way the active slide will stick to the first item in the second carousel
                    responsiveRefreshRate: 100
                }).on('changed.owl.carousel', syncPosition2);

            function syncPosition(el) {
                //if you set loop to false, you have to restore this next line
                //var current = el.item.index;
                //if you disable loop you have to comment this block
                var count = el.item.count - 1;
                var current = Math.round(el.item.index - (el.item.count / 2) - .5);

                if (current < 0) {
                    current = count;
                }
                if (current > count) {
                    current = 0;
                }

                //end block

                sync2
                    .find(".owl-item")
                    .removeClass("current")
                    .eq(current)
                    .addClass("current");
                var onscreen = sync2.find('.owl-item.active').length - 1;
                var start = sync2.find('.owl-item.active').first().index();
                var end = sync2.find('.owl-item.active').last().index();

                if (current > end) {
                    sync2.data('owl.carousel').to(current, 100, true);
                }
                if (current < start) {
                    sync2.data('owl.carousel').to(current - onscreen, 100, true);
                }
            }

            function syncPosition2(el) {
                if (syncedSecondary) {
                    var number = el.item.index;
                    sync1.data('owl.carousel').to(number, 100, true);
                }
            }

            sync2.on("click", ".owl-item", function(e) {
                e.preventDefault();
                var number = $(this).index();
                sync1.data('owl.carousel').to(number, 300, true);
            });
        });
    </script>
    <script>
        function accord(objID) {
            // debugger;
            // alert(objID);
            var idcr = '#' + objID;
            var prevID = $(idcr).prev().attr('id');
            // alert(prevID);
            var previousID = '#' + prevID;
            // $(previousID).toggle(1000);
            $(previousID).toggle(function() {
                // $(previousID).toggle(1000);
                if ($(previousID).is(":visible")) {
                    $(idcr).text('Hide Message');
                } else {
                    $(idcr).text('View Message');
                }
            });

        }
    </script>
    </body>
    </html>
