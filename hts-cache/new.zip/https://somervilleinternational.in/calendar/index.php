

<!DOCTYPE html
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Event Calendar</title>
    <link href='https://fonts.googleapis.com/css?family=Ubuntu:400,400italic,700,700italic,300,300italic'
        rel='stylesheet' type='text/css'>
    <!-- <link rel="stylesheet" href="fonts/stylesheet.css"> -->
    <!-- <link href="https://fonts.cdnfonts.com/css/sofia-pro" rel="stylesheet"> -->

    <!-- Jalendar files -->
    <link rel="stylesheet" href="jalendar/style/jalendar.css" type="text/css" />
    <script type="text/javascript" src="jalendar/js/jquery-1.10.2.min.js"></script>
    <!--jQuery-->
    <script type="text/javascript" src="jalendar/js/jalendar.min.js"></script>
    <!-- Jalendar files #end -->

    <script type="text/javascript">
    $(function() {
        $('#yourId').jalendar({
            //customDay: '11/01/2015',
            color: '#EEEEEE', // Unlimited Colors
            color2: '#EEEEEE', // Unlimited Colors
            //lang: 'TR'
        });
    });

    </script>
    <style>
        @font-face {
    font-family: Ranade-Regular;
    src: url(../fonts/Ranade-Regular.otf);
}

@font-face {
    font-family: Ranade-Medium;
    src: url(../fonts/Ranade-Medium.otf);
}

@font-face {
    font-family: Ranade-Bold;
    src: url(../fonts/Ranade-Bold.otf);
}
    body {
        font-family: Ranade-Light !important;
            /*'Segoe UI'*/
     
        font-weight: 100;
        font-size: 16px;
    }
    </style>
</head>

<body>

    <div class="container-fluid">
        <div class="row demos">
            <div class="tab-container" data-name="a">
                <div class="tab-content selected">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-4">

                                <div id="yourId" class="jalendar">


                                                                        <div class="added-event"
                                        data-date="31-3-2025"
                                        data-title="Eid-Ul-Fitar |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="14-3-2025"
                                        data-title="Holi |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="26-2-2025"
                                        data-title="Maha Shivaratri/Shivaratri |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="2-2-2025"
                                        data-title="Vasant Panchami |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="26-1-2025"
                                        data-title="Republic Day |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="25-12-2024"
                                        data-title="Christmas |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="24-11-2024"
                                        data-title="Guru Tegh Bahadur |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="15-11-2024"
                                        data-title="Guru Nanak Jayanti |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="7-11-2024"
                                        data-title="Chhat Puja (Pratihar Sashthi/Surya Sashthi) |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="3-11-2024"
                                        data-title="Bhai Duj |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="2-11-2024"
                                        data-title="Govardhan Puja |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="31-10-2024"
                                        data-title="Diwali/Deepavali |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="31-10-2024"
                                        data-title="Halloween  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="17-10-2024"
                                        data-title="Maharishi Valmiki Jayanti |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="12-10-2024"
                                        data-title="Dussehra |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="2-10-2024"
                                        data-title="Mahatma Gandhi Jayanti |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="16-9-2024"
                                        data-title="Milad Un-Nabi/Id-E-Milad |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="7-9-2024"
                                        data-title="Ganesh Chaturthi/Vinayaka Chaturthi |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="26-8-2024"
                                        data-title="Janmashtami |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="19-8-2024"
                                        data-title="Raksha Bandhan (Rakhi) |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="15-8-2024"
                                        data-title="Independence Day |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="21-7-2024"
                                        data-title="Guru Purnima |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="17-7-2024"
                                        data-title="Muharram/Ashura (Tentative Date) |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="17-6-2024"
                                        data-title="Eid Ul-Adha |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="16-6-2024"
                                        data-title="Fathers  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="23-5-2024"
                                        data-title="Buddha Purnima/Vesak |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="12-5-2024"
                                        data-title="Mothers  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="8-5-2024"
                                        data-title="Birthday Of Rabindranath |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="1-5-2024"
                                        data-title="International Worker  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="21-4-2024"
                                        data-title="Mahavir Jayanti |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="17-4-2024"
                                        data-title="Rama Navami |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="14-4-2024"
                                        data-title="Ambedkar Jayanti |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="13-4-2024"
                                        data-title="Vaisakhi  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="11-4-2024"
                                        data-title="Eid-Ul-Fitr |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="31-3-2024"
                                        data-title="Easter Day  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="29-3-2024"
                                        data-title="Good Friday |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="25-3-2024"
                                        data-title="Dolyatra  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="25-3-2024"
                                        data-title="Holi |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="24-3-2024"
                                        data-title="Holika Dahana |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="12-3-2024"
                                        data-title="Ramadan Start (Tentative Date)  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="8-3-2024"
                                        data-title="Maha Shivaratri/Shivaratri |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="5-3-2024"
                                        data-title="Maharishi Dayanand Saraswati Jayanti  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="24-2-2024"
                                        data-title="Guru Ravidas Jayanti |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="19-2-2024"
                                        data-title="Shivaji Jayanti  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="14-2-2024"
                                        data-title="Vasant Panchami |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="26-1-2024"
                                        data-title="Republic Day |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="25-1-2024"
                                        data-title="Hazarat Ali  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="22-1-2024"
                                        data-title="Government Notice |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="20-1-2024"
                                        data-title="PTM |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="17-1-2024"
                                        data-title="Guru Govind Singh Jayanti |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="15-1-2024"
                                        data-title="Makar Sankranti |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="15-1-2024"
                                        data-title="Pongal  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="14-1-2024"
                                        data-title="Lohri |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="1-1-2024"
                                        data-title="New Year  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="25-12-2023"
                                        data-title="Christmas |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="27-11-2023"
                                        data-title="Guru Nanak Jayanti |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="24-11-2023"
                                        data-title="Guru Tegh Bahadur |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="19-11-2023"
                                        data-title="Chhat Puja (Pratihar Sashthi/Surya Sashthi) |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="15-11-2023"
                                        data-title="Bhai Duj |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="13-11-2023"
                                        data-title="Govardhan Puja |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="12-11-2023"
                                        data-title="Diwali/Deepavali |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="12-11-2023"
                                        data-title="Naraka Chaturdasi  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="1-11-2023"
                                        data-title="Karaka Chaturthi (Karva Chauth)  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="28-10-2023"
                                        data-title="Maharishi Valmiki Jayanti |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="24-10-2023"
                                        data-title="Dussehra |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="23-10-2023"
                                        data-title="Maha Navami |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="22-10-2023"
                                        data-title="Maha Ashtami |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="21-10-2023"
                                        data-title="Maha Saptami |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="20-10-2023"
                                        data-title="First Day Of Durga Puja Festivities  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="15-10-2023"
                                        data-title="First Day Of Sharad Navratri  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="2-10-2023"
                                        data-title="Mahatma Gandhi Jayanti |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="28-9-2023"
                                        data-title="Id - E - Milad |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="28-9-2023"
                                        data-title="Milad Un-Nabi/Id-E-Milad (Tentative Date) |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="19-9-2023"
                                        data-title="Ganesh Chaturthi/Vinayaka Chaturthi |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="16-9-2023"
                                        data-title="Working Saturday  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="9-9-2023"
                                        data-title="Second Saturday |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="7-9-2023"
                                        data-title="Janmashtami |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="7-9-2023"
                                        data-title="Janmashtami |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="6-9-2023"
                                        data-title="Janmashtami (Smarta) |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="6-9-2023"
                                        data-title="Mid - Term Examinations  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="4-9-2023"
                                        data-title="Teachers' Day Celebration  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="30-8-2023"
                                        data-title="Raksha Bandhan (Rakhi) |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="29-8-2023"
                                        data-title="Onam  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="20-8-2023"
                                        data-title="Vinayaka Chathurthi  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="16-8-2023"
                                        data-title="Parsi New Year  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="15-8-2023"
                                        data-title="Independence Day |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="29-7-2023"
                                        data-title="Muharram/Ashura (Tentative Date) |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="29-6-2023"
                                        data-title="Bakrid/Eid Ul-Adha |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="20-6-2023"
                                        data-title="Rath Yatra  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="9-5-2023"
                                        data-title="Birthday Of Rabindranath  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="5-5-2023"
                                        data-title="Buddha Purnima/Vesak |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="1-5-2023"
                                        data-title="International Worker  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="22-4-2023"
                                        data-title="Ramzan Id/Eid-Ul-Fitar |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="21-4-2023"
                                        data-title="Jamat Ul-Vida (Tentative Date)  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="15-4-2023"
                                        data-title="Mesadi / Vaisakhadi  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="14-4-2023"
                                        data-title="Ambedkar Jayanti |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="14-4-2023"
                                        data-title="Vaisakhi |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="9-4-2023"
                                        data-title="Easter Day  ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="7-4-2023"
                                        data-title="Good Friday |  Holiday ">

                                    </div>
                                                                        <div class="added-event"
                                        data-date="4-4-2023"
                                        data-title="Mahavir Jayanti |  Holiday ">

                                    </div>
                                    

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
