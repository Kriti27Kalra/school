

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Meta Tags -->
    <title>Somerville Best School in Noida,Best CBSE School in Noida,Top School in Noida,Somerville International School Noida</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Somerville Best school In noida,Best CBSE school In noida,Top school in noida is Somerville.Nursery Admission Open in noida Somerville international school.School Admission in Noida Best International School in Noida Sec 132" />
    <meta name="keywords" content="Best School in Noida, Best School Noida, Top School in Noida, best school in Noida sec 132, Schools in Noida, AC Schools in Noida, Smart Class in Noida, Smart Class Schools in Noida, Smart Class Schools Noida, NEP Schools in Noida, Best Academic School in Noida, Christian Schools Near Me, Private Schools Near Me, Schools Near Me, School Near Noida Expressway, Best School in Noida Expressway, school near greater Noida expressway, Schools in Noida Sector 132, Schools in Noida Sec132" />

    <meta name="google-site-verification" content="JBT5oom5YFc9apZrP1pTmWLKOWLdIqS2fRW-VLSFfYM" />
    <meta name="GOOGLEBOT" content="index,follow" />
    <meta name="robots" content="index,follow" />
    <meta name="robots" content="all" />
    <link rel="canonical" href="https://somervilleinternational.in/" />
    <meta property="og:site_name" content="Somerville International School Noida" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Somerville Best School in Noida,Best CBSE School in Noida,Top School in Noida,Somerville International School Noida" />
    <meta property="og:description" content="Somerville Best school In noida,Best CBSE school In noida,Top school in noida is Somerville.Nursery Admission Open in noida Somerville international school.School Admission in Noida Best International School in Noida Sec 132" />
    <meta property="og:url" content="https://somervilleinternational.in/" />
    <meta property="og:image" content="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/new-logo-2.png" />
    <meta property="og:image:width" content="2182" />
    <meta property="og:image:height" content="541" />
    <meta name="og:email" content="school@somervilleinternational.in" />
    <meta name="og:phone_number" content="+91-9650506358" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="Somerville Best School in Noida,Best CBSE School in Noida,Top School in Noida,Somerville International School Noida" />
    <meta name="twitter:description" content="Somerville Best school In noida,Best CBSE school In noida,Top school in noida is Somerville.Nursery Admission Open in noida Somerville international school.School Admission in Noida Best International School in Noida Sec 132" />
    <meta name="twitter:url" content="https://somervilleinternational.in/" />
    <meta name="twitter:image" content="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/new-logo-2.png" />



    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-2G0NQL8V8Q"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        gtag('config', 'G-2G0NQL8V8Q');
    </script>

    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "EducationalOrganization",
            "name": "Somerville International School",
            "url": "https://somervilleinternational.in/",
            "logo": "https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/somerville-new-logo.png",
            "contactPoint": {
                "@type": "ContactPoint",
                "telephone": "+91 8076314108 +91 9650506358",
                "contactType": "emergency",
                "areaServed": "IN",
                "availableLanguage": ["en", "Hindi"]
            },
            "sameAs": [
                "https://www.facebook.com/people/Somerville-International-School/61550647783215/?mibextid=hIlR13",
                "https://www.instagram.com/somervilleinternational/",
                "https://www.youtube.com/channel/UCE0-GLJEFuQsDbtKHw__XCQ"
            ]
        }
    </script>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org/",
            "@type": "WebSite",
            "name": "Somerville International School",
            "url": "https://somervilleinternational.in/",
            "potentialAction": {
                "@type": "SearchAction",
                "target": "https://somervilleinternational.in/{search_term_string}https://somervilleinternational.in/",
                "query-input": "required name=search_term_string"
            }
        }
    </script>

    <!-- Stylesheets -->

    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">
    <link href="assets/css/color.css" rel="stylesheet">
    <link href="assets/css/fontawesome-all.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/custom-animate.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/swiper.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="shortcut icon" href="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/somervilleinternational-favicon.png" type="image/x-icon">
    <link rel="icon" href="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/somervilleinternational-favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="https://rawgit.com/LeshikJanz/libraries/master/Bootstrap/baguetteBox.min.css">

    <!-- Responsive -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-5ZK69HT');
    </script>
    <!-- End Google Tag Manager -->

</head>

<body>
    <div class="page-wrapper">

        <!-- Main Header -->
        <header class="main-header header-style-one bg-light">

            <div class="rs-toolbar bg-danger text-white">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="rs-toolbar-left">
                                <div class="welcome-message d-flex justify-content-between align-items-center w-100">
                                    <span class="rs-toolbar-start">
                                        <a href="tel:+919650506358" target="_blank"><i class="fa fa-phone mr-1"></i>
                                            +91-9650506358</a> <span class="divider mx-2">|</span>
                                        <a href="mailto:school@somervilleinternational.in" target="_blank"><i class="fa fa-envelope mr-1"></i> school@somervilleinternational.in</a>
                                    </span>
                                    <!-- <span class="rs-toolbar-start d-none d-lg-block">
                                        Affiliated To C.B.S.E <span class="divider mx-2">|</span> Code No : 2132183
                                    </span> -->
                                    <span class="rs-toolbar-end d-none d-lg-block social-icon-h">
                                        <a href="https://www.instagram.com/somervilleinternational/" target="_blank">
                                            <!-- <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/somervilleinternational-instagram.png"
                                                class="img-fluid" alt="Somerville International School, Noida" width=""> -->
                                            <i class="fa fa-instagram" aria-hidden="true"></i>
                                        </a>
                                        <a href="https://www.facebook.com/people/Somerville-International-School/61550647783215/?mibextid=hIlR13" target="_blank">
                                            <!-- <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/fb-icon.svg"
                                                class="img-fluid" alt="Somerville International School, Noida" width=""> -->
                                            <i class="fa fa-facebook" aria-hidden="true"></i>
                                        </a>
                                        <a href="https://www.youtube.com/channel/UCE0-GLJEFuQsDbtKHw__XCQ" target="_blank">
                                            <!-- <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/YouTube1.png"
                                                class="img-fluid" alt="Somerville International School, Noida" width=""> -->
                                            <i class="fa fa-youtube-play" aria-hidden="true"></i>
                                        </a>
                                        <a href="https://wa.me/+919650506358" target="_blank">
                                            <!-- <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/whatsapp-icon.png"
                                                class="img-fluid" alt="Somerville International School, Noida" width=""> -->
                                            <i class="fa fa-whatsapp" aria-hidden="true"></i>
                                        </a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Header Top -->
            <div class="header-top">
                <div class="auto-container">
                    <div class="inner-container">
                        <div class="left-column d-block">
                            <div class="left-img-column">
                                <a href="https://somervilleinternational.in/"><img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/somerville-new-logo.png" class="img-fluid" alt="Somerville International School, Noida Logo" width="450"></a>
                            </div>
                        </div>
                        <div class="main-menu main-menu-1 right-column d-flex align-items-center">
                            <ul class="btns-link">
                                <!-- <li><a href="https://sisnoida.edunexttechnologies.com/" target="_blank"
                                        class="erp-login erp-login-button btn btn-outline-danger">Edunext
                                        ERP<sup>TM</sup> Login</a></li> -->
                                <!-- <li><a href="https://forms.edunexttechnologies.com/forms/sisnoida/index.html"
                                        target="_blank" class="erp-login btn btn-primary">Contact Us</a>
                                            </li> -->
                                <!-- <li><a href="form-2025.php" class="new-btn1 new-btn-ani" target="_blank"><span class="i-icon"><i class="fa fa-sign-in"></i></span><span class="n-text">Admission Registration Form For 2025-26</a></li> -->
                                <li><a href="https://sisnoida.edunexttechnologies.com/" class="new-btn" target="_blank"><span class="i-icon"><i class="fa fa-sign-in"></i></span><span class="n-text">Edunext ERP<sup>TM</sup> Login</span></a></li>
                                <li><a href="fee_payment.php" class="new-btn" target="_blank"><span class="i-icon"><i class="fa fa-inr"></i></span><span class="n-text">Fee
                                            Payment</span></a></li>
                                <li><a href="contact-us.php" class="new-btn" target="_blank"><span class="i-icon"><i class="fa fa-address-book-o"></i></span><span class="n-text">Contact
                                            Us</span></a></li>
                                <!-- <li><a href="https://sisnoida.edunexttechnologies.com/DirectStudentOnlineFee"
                                        target="_blank" class="erp-login btn btn-primary">Pay Fee Online</a></li> -->
                                <!-- <li><a href="https://resources.edunexttechnologies.com/ppt/Somervill-School.pdf"
                                        target="_blank" class="erp-login btn btn-primary">Mobile App Manual</a></li> -->
                                <!-- <li><a href="https://sisnoida.edunexttechnologies.com/mvc/std/DynamicEnquiryForm?id=gm44E2x75eawnpF5K7VGUQ&istrue=true"
                                        target="_blank" class="erp-login btn btn-primary">Enquiry Form</a></li> -->
                                <!-- <li><a href="https://forms.edunexttechnologies.com/forms/somerville-nursery/registration/"
                                        target="_blank" class="erp-login btn btn-primary">Online Admissions</a>
                                </li> -->

                                <!-- <li class="dropdown  erp-login  btn btn-primary">Online Admissions
                                    <ul class="">
                                        <li class=""><a href="admission_nursery">Admission to Nursery</a></li>
                                        <li class=""><a href="admission_kg">Admission to K.G</a></li>
                                        <li class=""><a href="admission_i_v">Admission to Classes I-V</a></li>
                                        <li class=""><a href="admission_vi_ix_xi">Admission to Classes VI-IX &
                                                XI</a></li>
                                    </ul>

                                </li> -->


                            </ul>
                        </div>
                    </div>
                </div>
            </div>



            <!-- Header Upper -->
            <div class="header-upper">
                <div class="auto-container">
                    <div class="row justify-content-end">
                        <div class="col-md-8">
                            <div class="right-column">
                                <!--Nav Box-->
                                <div class="navbar navbar-expand-lg navbar-light bg-navber">
                                    <div class="nav-outer">
                                        <!--Mobile Navigation Toggler-->
                                        <div class="mobile-nav-toggler"><img src="https://resources.edunexttechnologies.com/assets/images/menu-icon-bar.png" alt="Somerville International School, Noida"></div>

                                        <!-- Main Menu -->
                                        <nav class="main-menu navbar-expand-md navbar-light">
                                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                                <ul class='navigation'><li class='' ><a   href='https://somervilleinternational.in/'> Home</a></li><li class='dropdown'  ><a  href='#'>About Us</a><ul class=''><li class='dropdown' ><a  href='#'>History</a><ul  class='sub-menu'><li ><a  href='about-the-school'>The School</a></li><li ><a  href='the-lott-carey-mission'>The Lott Carey Baptist Mission</a></li></ul><li class="" ><a  href='vision-mission-moto'>Vision, Mission & Motto</a><li class="" ><a  href='board-of-management.php'>Management & Administration</a></li></ul></li><li class='dropdown'  ><a  href='#'>Prospectus</a><ul class=''><li class="" ><a  href='school-song'>School Song</a><li class="" ><a  href='school-status'>School Status</a><li class="" ><a  href='curriculum'>Curriculum</a><li class="" ><a  href='infrastructure-new'>Infrastructure</a><li class="" ><a  href='school-timings'>School Timings</a><li class="" ><a  href='uniform'>Uniform</a><li class="" ><a  href='list-of-holidays'>List of Holidays</a><li class="" ><a  href='https://resources.edunexttechnologies.com/web-data/somervilleinternational/pdf/TEACHER_WORKSHOP.pdf'>Staff Development</a></li></ul></li><li class='dropdown'  ><a  href='#'>School Levels</a><ul class=''><li class="" ><a  href='preparatory-school'>Preparatory School</a><li class="" ><a  href='primary-school'>Primary School</a><li class="" ><a  href='secondary-school'>Secondary School</a><li class="" ><a  href='senior-secondary-school'>Senior-Secondary School</a></li></ul></li><li class='dropdown'  ><a  href='#'>Student Life</a><ul class=''><li class="" ><a  href='clubs.php'>Clubs</a><li class="" ><a  href='sports'>Sports</a><li class="" ><a  href='olympiads'>Olympiads</a><li class="" ><a  href='intra-school-activities'>Intra-school Activities</a><li class="" ><a  href='inter-school-activities'>Inter-school Activities</a><li class="" ><a  href='counselling-and-guidance-department'>Counselling And Guidance Department</a><li class="" ><a  href='community-service'>Community Service</a><li class="" ><a  href='house-system-and-student-council'>House System and Student Council</a></li></ul></li><li class='dropdown'  ><a  href='#'>Admissions</a><ul class=''><li class="" ><a  href='admission-process'>Admission Process</a><li class="" ><a  href='forms.php'>Admission Registration Form</a><li class="" ><a  href='fee-structure'>Fee Structure</a><li class="" ><a  href='faq'>FAQ</a></li></ul></li><li class='dropdown'  ><a  href='#'>Gallery</a><ul class=''><li class="" ><a  href='gallery.php'>Photo Gallery</a><li class="" ><a  href='video-gallery.php'>Video Gallery</a><li class="" ><a  href='wall-magazine'>School Magazine</a><li class="" ><a  href='class-photographs.php'>Class Photographs</a><li class="" ><a  href='all-testimonials.php'>Testimonials</a></li></ul></li><li class='' ><a   href='career.php'> Careers</a></li><li class='dropdown'  ><a  href='#'>Transfer Certificate</a><ul class=''><li class="" ><a  href='pdf/Application-form-for-TC-1.pdf'>Apply</a><li class="" ><a  href='transfer-certificate'>Access</a></li></ul></li></ul>                                            </div>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Header Upper-->

            <!-- Sticky Header  -->
            <div class="sticky-header">
                <div class="header-upper">
                    <div class="auto-container">
                        <div class="inner-container">
                            <div class="right-column">
                                <!--Nav Box-->
                                <div class="nav-outer">
                                    <!--Mobile Navigation Toggler-->
                                    <div class="mobile-nav-toggler"><img src="https://resources.edunexttechnologies.com/assets/images/menu-icon-bar.png" alt="Somerville International School, Noida"></div>

                                    <!-- Main Menu -->
                                    <nav class="main-menu navbar-expand-md navbar-light">
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- End Sticky Menu -->

            <!-- Mobile Menu  -->
            <div class="mobile-menu">
                <div class="menu-backdrop"></div>
                <div class="close-btn"><span class="icon fa fa-times"></span></div>

                <nav class="menu-box">
                    <div class="nav-logo"><a href="https://somervilleinternational.in/">
                            <!-- <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/footer-new-logo-1.png"
                                width="230" alt="Somerville International School, Noida Logo" title=""> -->
                            <div style=" margin-bottom: 20px;" class="d-flex">
                                <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/SIS-logo-white.png" alt="Somerville International School, Noida Logo" style="width: 21%;">
                                <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/footer-logo-new-2_n.png" alt="Somerville International School, Noida Logo" style="width: 84%;margin-left: 4px;">
                            </div>
                        </a></div>
                    <div class="menu-outer">
                        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                    </div>
                    <!--Social Links-->
                    <div class="social-links">
                        <ul class="clearfix social-icon-h-m">
                            <li><a href="https://instagram.com/somervilleinternational" target="_blank" class=""><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://www.facebook.com/people/Somerville-International-School/61550647783215/?mibextid=hIlR13" target="_blank" class=""><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://www.youtube.com/channel/UCE0-GLJEFuQsDbtKHw__XCQ" target="_blank" class=""><i class="fa fa-youtube"></i></a></li>
                            <li><a href="https://wa.me/+919650506358" target="_blank" class=""><i class="fa fa-whatsapp"></i></a></li>
                        </ul>
                    </div>
                </nav>
            </div><!-- End Mobile Menu -->

            <div class="nav-overlay">
                <div class="cursor"></div>
                <div class="cursor-follower"></div>
            </div>
        </header>
        <!-- End Main Header -->

        <style>
            .navbar-nav li:hover>ul.dropdown-menu {
                display: block;
            }

            .dropdown-submenu {
                position: relative;
            }

            .dropdown-submenu>.dropdown-menu {
                top: 0;
                left: 100%;
                margin-top: -6px;
            }

            /* rotate caret on hover */
            .dropdown-menu>li>a:hover:after {
                text-decoration: underline;
                transform: rotate(-90deg);
            }
        </style>

<!-- Page Title -->
<section class="page-title"
    style="background: url(https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/internal-top.svg) no-repeat; background-size: cover; background-position: center;">
    <div class="auto-container">
        <div class="content-box">
            <div class="content-wrapper">
                <div class="title">
                    <h1>Class Photographs</h1>
                </div>
                <!-- <ul class="bread-crumb">
                    <li><a href="index.php">Home</a></li>
                    <li>Class Photographs</li>
                </ul> -->
            </div>
        </div>
    </div>
</section>

<!-- Blog Section -->
<section class="about-section about-inner-section">
    <div class="inner-page-bg">
        <!-- <div class="innerpage-top">
            <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/assets-1.gif"
                alt="somervilleinternational">
        </div> -->
        <div class="auto-container">
            <div class="row">


                                <div class="col-lg-4 news-block">
                    <div class="inner-box">
                        <div class="image"><img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1748597883020_1.png" alt="">
                        </div>
                        <div class="lower-content">
                            <h4>Class Photograph Session 2024-25</h4>
                            <div class="link-btn d-flex justify-content-between align-items-center">
                                <span>30-May-2025</span>
                                <a href="photo-gallery.php?gal_id=206"
                                    class="theme-btn bg-white btn-style-one style-three"><span>View More</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                                <div class="col-lg-4 news-block">
                    <div class="inner-box">
                        <div class="image"><img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1717571347118_1A.jpg" alt="">
                        </div>
                        <div class="lower-content">
                            <h4>Class Photograph Session 2023-24</h4>
                            <div class="link-btn d-flex justify-content-between align-items-center">
                                <span>05-Jun-2023</span>
                                <a href="photo-gallery.php?gal_id=119"
                                    class="theme-btn bg-white btn-style-one style-three"><span>View More</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                                <div class="col-lg-4 news-block">
                    <div class="inner-box">
                        <div class="image"><img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1686393491618_class20222301.png" alt="">
                        </div>
                        <div class="lower-content">
                            <h4>Class Photographs Session 2022-23</h4>
                            <div class="link-btn d-flex justify-content-between align-items-center">
                                <span>25-Jun-2022</span>
                                <a href="photo-gallery.php?gal_id=48"
                                    class="theme-btn bg-white btn-style-one style-three"><span>View More</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                                <div class="col-lg-4 news-block">
                    <div class="inner-box">
                        <div class="image"><img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1686393072956_class20181901.jpg" alt="">
                        </div>
                        <div class="lower-content">
                            <h4>Class Photographs Session 2019-20</h4>
                            <div class="link-btn d-flex justify-content-between align-items-center">
                                <span>29-Jun-2019</span>
                                <a href="photo-gallery.php?gal_id=47"
                                    class="theme-btn bg-white btn-style-one style-three"><span>View More</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                                <div class="col-lg-4 news-block">
                    <div class="inner-box">
                        <div class="image"><img src="https://edunext-main-storage-cf.edunexttechnologies.com/svis/school___static/1686392894299_class20181901.jpg" alt="">
                        </div>
                        <div class="lower-content">
                            <h4>Class Photographs Session 2018-19</h4>
                            <div class="link-btn d-flex justify-content-between align-items-center">
                                <span>13-Jun-2018</span>
                                <a href="photo-gallery.php?gal_id=46"
                                    class="theme-btn bg-white btn-style-one style-three"><span>View More</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                


            </div>

        </div>
    </div>

</section>

<style>
.news-block .image img {
    height: 200px;
}
</style>

    <footer class="main-footer pt-4 pt-md-0 mt-0" style="background: url('https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/somervilleinternational-footer-bg.png') no-repeat; background-size: cover; background-position: center;">
        <div class="container-fluid">
            <!--Widgets Section-->
            <div class="widgets-section">
                <div class="row clearfix justify-content-between">

                    <!--Column-->
                    <div class="column col-lg-4 col-md-6">
                        <div class="widget contact-widget about-widget py-md-4 pt-lg-5">
                            <div class="widget-content">
                                <div style=" margin-bottom: 20px;" class="d-flex">
                                    <a href="https://somervilleinternational.in/">
                                        <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/SIS-logo-white.png" alt="Somerville International School, Noida Logo" style="width: 20%;">
                                        <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/footer-logo-new-2_n.png" alt="Somerville International School, Noida Logo" style="width: 77%; margin-left: 4px;">
                                    </a>
                                </div>
                                <p class="text-white text-justify d-none d-md-block">The mission of the school is to
                                    provide myriad opportunities to
                                    each child. The school believes that each child is unique and special and is blessed
                                    with immense potential. The endeavour is to guide each child as he/she charters a
                                    route to happiness and excellence.</p>
                                <ul class="social-links wow fadeInLeft social-icon">
                                    <li><a href="https://www.instagram.com/somervilleinternational/" target="_blank">
                                           
                                            <i class="fa fa-instagram" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.facebook.com/people/Somerville-International-School/61550647783215/?mibextid=hIlR13" target="_blank">
                                            <i class="fa fa-facebook" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.youtube.com/channel/UCE0-GLJEFuQsDbtKHw__XCQ" target="_blank">                      
                                            <i class="fa fa-youtube-play" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://wa.me/+919650506358" target="_blank">
            
                                            <i class="fa fa-whatsapp" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!--Column-->
                    <div class="column col-lg-4 col-md-6">
                        <div class="widget contact-widget about-widget py-md-4 pt-lg-5 mb-4">
                            <h3 class="widget-title">Quick Links</h3>
                            <div class="widget-content">
                                <div class="row">
                                    <div class="col-md-6">
                                        <ul class="contact-info">
                                            <li class="wow fadeInUp" >
                                                <a href="about-the-school" target="_blank">The School</a>
                                            </li>
                                            <li class="wow fadeInUp">
                                                <a href="admission-process" target="_blank">Admission Process</a>
                                            </li>

                                            <li class="wow fadeInUp">
                                                <a href="clubs.php" target="_blank">Clubs</a>
                                            </li>
                                            <li class=" wow fadeInUp">
                                                <a href="gallery.php" target="_blank">Photo Gallery</a>
                                            </li>
                                            <li class=" wow fadeInUp">
                                                <a href="career.php" target="_blank">Careers</a>
                                            </li>
                                            <li class="wow fadeInUp">
                                                <a href="contact-us.php" target="_blank">Contact Us</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="app-store mt-3 mt-md-0">
                                            <a href="https://play.google.com/store/search?q=edunext+parent&c=apps&pli=1" class="" target="_blank"><img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/gp.png" class="mt-md-3 mb-md-3 mb-sm-3" alt="Somerville International School, Noida"></a>
                                            <a href="https://apps.apple.com/in/app/edunext-parent/id1516241231" class="" target="_blank"><img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/as.png" class="mt-md-3 mb-md-3 mb-sm-3" alt="Somerville International School, Noida"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                    <div class="column col-lg-4 col-md-6 p-md-0 d-none d-md-block">                   
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7012.042259354631!2d77.374881!3d28.509012000000002!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce629043d5d05%3A0x7635abf24b6a4c2a!2sSomerville%20International%20School!5e0!3m2!1sen!2sus!4v1703069423213!5m2!1sen!2sus" width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>

                </div>
            </div>
        </div>
        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="container auto-container">
                <div class="wrapper-box">
                    <div class="copyright">
		    <div class="text">Ⓒ Copyright 2025 <br class="d-block d-md-none"><span class="text-warning">|</span> <span class="Lincoln ">Somer<span class="Alpine v-size3">v</span>ille International
                                School</span> <br class="d-block d-md-none"> <span class="text-warning">|</span>
                            Designed & Maintained by <a href="https://edunexttechnologies.com/" target="_blank" class="text-light">Edunext
                                Technologies</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    </div>
    <!--End pagewrapper-->

    <!--Scroll to top-->
    <div class="scroll-to-top scroll-to-target" data-target="html">
        <img src="https://resources.edunexttechnologies.com/web-data/somervilleinternational/img/46.svg">
    </div>

    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/fjs.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js">
    </script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/swiper.min.js"></script>
    <script src="assets/js/modernizr-custom.js"></script>
    <script src="assets/js/jquery.slicebox.js"></script>
    <script src="assets/js/script.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#newmodal').modal('show');
        });
    </script>

    <script>
        $(".link").on('click', function() {
            $(".link").removeClass('active');
            $(this).addClass('active');
            var $submenu_first = $(this).next(".submenu");
            var $arrow_first = $(this).find('.arrow-up');

            if ($submenu_first.is(":visible")) {
                $submenu_first.slideUp();
                $(this).removeClass('active');
                $arrow_first.animate({
                    rotation: 0
                }, {
                    step: function(now, fx) {
                        $(this).css('transform', 'rotate(' + now + 'deg)');
                    },
                    duration: 'slow'
                });
            } else {
                $(".submenu").slideUp();
                $submenu_first.slideDown();
                $arrow_first.animate({
                    rotation: 90
                }, {
                    step: function(now, fx) {
                        $(this).css('transform', 'rotate(' + now + 'deg)');
                    },
                    duration: 'slow'
                });
            }
        });
    </script>

    <script type="text/javascript">
        $(function() {

            var Page = (function() {

                var $navArrows = $('#nav-arrows').hide(),
                    $shadow = $('#shadow').hide(),
                    slicebox = $('#sb-slider').slicebox({
                        onReady: function() {

                            $navArrows.show();
                            $shadow.show();

                        },
                        orientation: 'r',
                        cuboidsRandom: true
                    }),

                    init = function() {

                        initEvents();

                    },
                    initEvents = function() {

                        // add navigation events
                        $navArrows.children(':first').on('click', function() {

                            slicebox.next();
                            return false;

                        });

                        $navArrows.children(':last').on('click', function() {

                            slicebox.previous();
                            return false;

                        });

                    };

                return {
                    init: init
                };

            })();

            Page.init();

        });
    </script>

    <script>
        baguetteBox.run('#gallery');
    </script>

    <script type="text/javascript">
        $(document).ready(function() {
            $(".team_carousel").owlCarousel({
                navigation: false,
                slideSpeed: 500,
                paginationSpeed: 800,
                rewindSpeed: 1000,
                singleItem: true,
                autoPlay: false,
                stopOnHover: true,
                nav: true,
                dots: true,
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            var sync1 = $("#sync1");
            var sync2 = $("#sync2");
            var slidesPerPage = 4; //globaly define number of elements per page
            var syncedSecondary = true;
            sync1.owlCarousel({
                items: 1,
                slideSpeed: 2000,
                nav: true,
                autoplay: false,
                dots: false,
                loop: true,
                responsiveRefreshRate: 200,
                navText: [
                    '<svg width="100%" height="100%" viewBox="0 0 11 20"><path style="fill:none;stroke-width: 2px;stroke: #fff;" d="M9.554,1.001l-8.607,8.607l8.607,8.606"/></svg>',
                    '<svg width="100%" height="100%" viewBox="0 0 11 20" version="1.1"><path style="fill:none;stroke-width: 2px;stroke: #fff;" d="M1.054,18.214l8.606,-8.606l-8.606,-8.607"/></svg>'
                ],
            }).on('changed.owl.carousel', syncPosition);

            sync2
                .on('initialized.owl.carousel', function() {
                    sync2.find(".owl-item").eq(0).addClass("current");
                })
                .owlCarousel({
                    items: slidesPerPage,
                    dots: false,
                    nav: true,
                    smartSpeed: 200,
                    slideSpeed: 500,
                    slideBy: slidesPerPage, //alternatively you can slide by 1, this way the active slide will stick to the first item in the second carousel
                    responsiveRefreshRate: 100
                }).on('changed.owl.carousel', syncPosition2);

            function syncPosition(el) {
                //if you set loop to false, you have to restore this next line
                //var current = el.item.index;
                //if you disable loop you have to comment this block
                var count = el.item.count - 1;
                var current = Math.round(el.item.index - (el.item.count / 2) - .5);

                if (current < 0) {
                    current = count;
                }
                if (current > count) {
                    current = 0;
                }

                //end block

                sync2
                    .find(".owl-item")
                    .removeClass("current")
                    .eq(current)
                    .addClass("current");
                var onscreen = sync2.find('.owl-item.active').length - 1;
                var start = sync2.find('.owl-item.active').first().index();
                var end = sync2.find('.owl-item.active').last().index();

                if (current > end) {
                    sync2.data('owl.carousel').to(current, 100, true);
                }
                if (current < start) {
                    sync2.data('owl.carousel').to(current - onscreen, 100, true);
                }
            }

            function syncPosition2(el) {
                if (syncedSecondary) {
                    var number = el.item.index;
                    sync1.data('owl.carousel').to(number, 100, true);
                }
            }

            sync2.on("click", ".owl-item", function(e) {
                e.preventDefault();
                var number = $(this).index();
                sync1.data('owl.carousel').to(number, 300, true);
            });
        });
    </script>
    <script>
        function accord(objID) {
            // debugger;
            // alert(objID);
            var idcr = '#' + objID;
            var prevID = $(idcr).prev().attr('id');
            // alert(prevID);
            var previousID = '#' + prevID;
            // $(previousID).toggle(1000);
            $(previousID).toggle(function() {
                // $(previousID).toggle(1000);
                if ($(previousID).is(":visible")) {
                    $(idcr).text('Hide Message');
                } else {
                    $(idcr).text('View Message');
                }
            });

        }
    </script>
    </body>
    </html>
